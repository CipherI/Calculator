let display = document.getElementById('display');
let firstOperand = null;
let operator = null;
let secondOperand = null;

function appendNumber(number) {
  display.textContent += number;
}

function appendOperator(op) {
  firstOperand = parseFloat(display.textContent);
  operator = op;
  display.textContent += op;
}

function calculate() {
  secondOperand = parseFloat(display.textContent.slice(display.textContent.lastIndexOf(operator) + 1));
  let result;
  switch (operator) {
    case '+':
      result = firstOperand + secondOperand;
      break;
    case '-':
      result = firstOperand - secondOperand;
      break;
    case '*':
      result = firstOperand * secondOperand;
      break;
    case '÷':
      result = firstOperand / secondOperand;
      break;
  }
  display.textContent = result;
  firstOperand = null;
  operator = null;
}

function clearDisplay() {
  display.textContent = '';
}

function backspace() {
  display.textContent = display.textContent.slice(0, -1);
}